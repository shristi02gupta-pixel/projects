import React, { useState, useEffect, useRef } from 'react';
import { FileText, Zap, Copy, Download, Trash2, Settings, Brain, Sparkles, ChevronDown, ChevronUp, Mic, MicOff, Volume2, VolumeX } from 'lucide-react';

export default function DarkAITextSummarizer() {
  const [inputText, setInputText] = useState('');
  const [summary, setSummary] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [wordCount, setWordCount] = useState(0);
  const [summaryLength, setSummaryLength] = useState('medium');
  const [summaryStyle, setSummaryStyle] = useState('bullet');
  const [showSettings, setShowSettings] = useState(false);
  const [generationTime, setGenerationTime] = useState(null);
  const [copySuccess, setCopySuccess] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [voiceEnabled, setVoiceEnabled] = useState(true);
  const [transcript, setTranscript] = useState('');
  const [interimTranscript, setInterimTranscript] = useState('');
  const [showVoiceHelp, setShowVoiceHelp] = useState(false);
  
  const recognitionRef = useRef(null);
  const speechSynthesisRef = useRef(null);

  useEffect(() => {
    const words = inputText.trim().split(/\s+/).filter(word => word.length > 0);
    setWordCount(words.length);
  }, [inputText]);

  // Initialize speech recognition
  useEffect(() => {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = true;
      recognitionRef.current.interimResults = true;
      recognitionRef.current.lang = 'en-US';

      recognitionRef.current.onresult = (event) => {
        let interimTranscript = '';
        let finalTranscript = '';

        for (let i = event.resultIndex; i < event.results.length; i++) {
          const transcript = event.results[i][0].transcript;
          if (event.results[i].isFinal) {
            finalTranscript += transcript;
          } else {
            interimTranscript += transcript;
          }
        }

        setInterimTranscript(interimTranscript);
        
        if (finalTranscript) {
          setInputText(prev => prev + finalTranscript + ' ');
          setTranscript(finalTranscript);
        }
      };

      recognitionRef.current.onerror = (event) => {
        console.error('Speech recognition error:', event.error);
        setIsListening(false);
        speak('Speech recognition error occurred. Please try again.');
      };

      recognitionRef.current.onend = () => {
        setIsListening(false);
        setInterimTranscript('');
      };
    }
  }, []);

  const speak = (text) => {
    if (!voiceEnabled) return;
    
    // Cancel any ongoing speech
    speechSynthesis.cancel();
    
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 0.9;
    utterance.pitch = 1;
    utterance.volume = 0.8;
    
    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    
    speechSynthesis.speak(utterance);
  };

  const startListening = () => {
    if (recognitionRef.current && !isListening) {
      setIsListening(true);
      recognitionRef.current.start();
      speak('Listening for your text. Speak clearly.');
    }
  };

  const stopListening = () => {
    if (recognitionRef.current && isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
      speak('Voice input stopped.');
    }
  };

  const clearVoiceInput = () => {
    setTranscript('');
    setInterimTranscript('');
    if (isListening) {
      stopListening();
    }
  };

  const readSummary = () => {
    if (summary) {
      speak(`Here is your AI generated summary: ${summary}`);
    } else {
      speak('No summary available yet. Please generate a summary first.');
    }
  };

  const generateSummary = async () => {
    if (!inputText.trim()) return;
    
    setIsGenerating(true);
    const startTime = Date.now();
    
    // Simulate AI processing with realistic delay
    await new Promise(resolve => setTimeout(resolve, 2000 + Math.random() * 2000));
    
    const endTime = Date.now();
    setGenerationTime(((endTime - startTime) / 1000).toFixed(1));
    
    // Generate mock summary based on settings
    const mockSummary = generateMockSummary(inputText, summaryLength, summaryStyle);
    setSummary(mockSummary);
    setIsGenerating(false);
    
    // Voice feedback
    if (voiceEnabled) {
      speak('Summary generated successfully. Your AI summary is ready.');
    }
  };

  const generateMockSummary = (text, length, style) => {
    const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 0);
    let summaryCount;
    
    switch (length) {
      case 'short': summaryCount = Math.min(2, sentences.length); break;
      case 'medium': summaryCount = Math.min(4, sentences.length); break;
      case 'long': summaryCount = Math.min(6, sentences.length); break;
      default: summaryCount = Math.min(4, sentences.length);
    }
    
    const selectedSentences = sentences.slice(0, summaryCount);
    
    if (style === 'bullet') {
      return selectedSentences.map((sentence, index) => 
        `• ${sentence.trim()}.`
      ).join('\n\n');
    } else if (style === 'numbered') {
      return selectedSentences.map((sentence, index) => 
        `${index + 1}. ${sentence.trim()}.`
      ).join('\n\n');
    } else {
      return selectedSentences.join('. ') + '.';
    }
  };

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(summary);
      setCopySuccess(true);
      setTimeout(() => setCopySuccess(false), 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  };

  const downloadSummary = () => {
    const element = document.createElement('a');
    const file = new Blob([summary], { type: 'text/plain' });
    element.href = URL.createObjectURL(file);
    element.download = 'ai-summary.txt';
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  const clearAll = () => {
    setInputText('');
    setSummary('');
    setGenerationTime(null);
    setTranscript('');
    setInterimTranscript('');
    if (isListening) {
      stopListening();
    }
    if (voiceEnabled) {
      speak('All content cleared.');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-black text-white">
      {/* Header */}
      <div className="bg-gray-900/50 backdrop-blur-sm border-b border-gray-700/50 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="relative">
                <Brain className="w-8 h-8 text-purple-400" />
                <Sparkles className="w-4 h-4 text-yellow-400 absolute -top-1 -right-1 animate-pulse" />
              </div>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
                  AI Text Summarizer
                </h1>
                <p className="text-gray-400 text-sm">Powered by Advanced AI • Lightning Fast</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <button
                onClick={() => setShowSettings(!showSettings)}
                className="p-2 rounded-lg bg-gray-800 hover:bg-gray-700 transition-all duration-200 border border-gray-600"
              >
                <Settings className="w-5 h-5 text-gray-300" />
              </button>
              <button
                onClick={() => setVoiceEnabled(!voiceEnabled)}
                className={`p-2 rounded-lg transition-all duration-200 border ${
                  voiceEnabled 
                    ? 'bg-green-600 border-green-500 text-white' 
                    : 'bg-gray-800 border-gray-600 text-gray-400'
                }`}
                title={voiceEnabled ? 'Voice feedback enabled' : 'Voice feedback disabled'}
              >
                {voiceEnabled ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
              </button>
              <div className="flex items-center space-x-2 text-sm text-gray-400">
                <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                <span>AI Online</span>
              </div>
              {isSpeaking && (
                <div className="flex items-center space-x-2 text-sm text-blue-400">
                  <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse"></div>
                  <span>Speaking...</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Settings Panel */}
        {showSettings && (
          <div className="mb-8 bg-gray-800/50 backdrop-blur-sm rounded-xl border border-gray-700/50 p-6">
            <h3 className="text-lg font-semibold mb-4 text-purple-400">AI Configuration</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Summary Length</label>
                <select
                  value={summaryLength}
                  onChange={(e) => setSummaryLength(e.target.value)}
                  className="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                >
                  <option value="short">Short (2-3 points)</option>
                  <option value="medium">Medium (4-5 points)</option>
                  <option value="long">Long (6+ points)</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Summary Style</label>
                <select
                  value={summaryStyle}
                  onChange={(e) => setSummaryStyle(e.target.value)}
                  className="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                >
                  <option value="bullet">Bullet Points</option>
                  <option value="numbered">Numbered List</option>
                  <option value="paragraph">Paragraph</option>
                </select>
              </div>
            </div>
            <div className="mt-6 p-4 bg-gray-900/50 rounded-lg border border-gray-600">
              <h4 className="text-sm font-medium text-green-400 mb-2">Voice Features</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-gray-300">
                <div>
                  <p><strong>Voice Input:</strong> Click microphone to dictate text</p>
                  <p><strong>Voice Feedback:</strong> AI speaks confirmations</p>
                </div>
                <div>
                  <p><strong>Read Summary:</strong> AI reads your summary aloud</p>
                  <p><strong>Voice Commands:</strong> Clear, generate, and more</p>
                </div>
              </div>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Input Section */}
          <div className="space-y-6">
            <div className="bg-gray-800/50 backdrop-blur-sm rounded-xl border border-gray-700/50 p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-semibold text-purple-400 flex items-center">
                  <FileText className="w-5 h-5 mr-2" />
                  Input Text
                </h2>
                <div className="flex items-center space-x-4">
                  <button
                    onClick={isListening ? stopListening : startListening}
                    className={`p-2 rounded-lg transition-all duration-200 border ${
                      isListening 
                        ? 'bg-red-600 border-red-500 text-white animate-pulse' 
                        : 'bg-blue-600 border-blue-500 text-white hover:bg-blue-700'
                    }`}
                    title={isListening ? 'Stop voice input' : 'Start voice input'}
                  >
                    {isListening ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
                  </button>
                  <div className="flex items-center space-x-2 text-sm text-gray-400">
                    <span>{wordCount} words</span>
                    {wordCount > 0 && (
                      <div className={`w-2 h-2 rounded-full ${
                        wordCount < 50 ? 'bg-red-400' : 
                        wordCount < 200 ? 'bg-yellow-400' : 
                        'bg-green-400'
                      }`}></div>
                    )}
                  </div>
                </div>
              </div>
              
              {/* Voice Status */}
              {(isListening || interimTranscript) && (
                <div className="mb-4 p-3 bg-blue-900/30 border border-blue-500/50 rounded-lg">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      {isListening && (
                        <>
                          <div className="w-2 h-2 bg-red-400 rounded-full animate-pulse"></div>
                          <span className="text-red-400 text-sm font-medium">Recording...</span>
                        </>
                      )}
                    </div>
                    {isListening && (
                      <button
                        onClick={clearVoiceInput}
                        className="text-gray-400 hover:text-red-400 text-sm underline"
                      >
                        Clear Voice
                      </button>
                    )}
                  </div>
                  {interimTranscript && (
                    <p className="text-gray-300 text-sm mt-2 italic">
                      "{interimTranscript}"
                    </p>
                  )}
                </div>
              )}
              
              <textarea
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder="Paste your text here to get an AI-powered summary. The more content you provide, the better the summary will be..."
                className="w-full h-80 bg-gray-900/50 border border-gray-600 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent resize-none"
                style={{ fontFamily: 'Monaco, Consolas, monospace' }}
              />
              
              <div className="flex items-center justify-between mt-4">
                <div className="flex items-center space-x-2">
                  <div className="text-xs text-gray-400">
                    {wordCount < 50 ? 'Add more text for better results' : 
                     wordCount < 200 ? 'Good length for summarization' : 
                     'Excellent - AI will provide detailed summary'}
                  </div>
                </div>
                <div className="flex space-x-3">
                  <button
                    onClick={clearAll}
                    className="px-4 py-2 bg-gray-700 hover:bg-gray-600 rounded-lg transition-all duration-200 border border-gray-600 flex items-center space-x-2"
                  >
                    <Trash2 className="w-4 h-4" />
                    <span>Clear</span>
                  </button>
                  <button
                    onClick={generateSummary}
                    disabled={!inputText.trim() || isGenerating}
                    className="px-6 py-2 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 disabled:from-gray-600 disabled:to-gray-600 rounded-lg transition-all duration-200 flex items-center space-x-2 font-semibold"
                  >
                    {isGenerating ? (
                      <>
                        <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                        <span>AI Processing...</span>
                      </>
                    ) : (
                      <>
                        <Zap className="w-4 h-4" />
                        <span>Summarize</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Output Section */}
          <div className="space-y-6">
            <div className="bg-gray-800/50 backdrop-blur-sm rounded-xl border border-gray-700/50 p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-semibold text-green-400 flex items-center">
                  <Brain className="w-5 h-5 mr-2" />
                  AI Summary
                </h2>
                {generationTime && (
                  <div className="text-sm text-gray-400">
                    Generated in {generationTime}s
                  </div>
                )}
              </div>
              
              {summary ? (
                <div className="space-y-4">
                  <div className="bg-gray-900/50 border border-gray-600 rounded-lg p-4 min-h-80">
                    <pre className="text-gray-100 whitespace-pre-wrap text-sm leading-relaxed" style={{ fontFamily: 'Inter, sans-serif' }}>
                      {summary}
                    </pre>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2 text-sm text-gray-400">
                      <Sparkles className="w-4 h-4 text-yellow-400" />
                      <span>Summary generated by AI</span>
                    </div>
                    <div className="flex space-x-3">
                      <button
                        onClick={readSummary}
                        className="px-4 py-2 bg-purple-600 hover:bg-purple-700 rounded-lg transition-all duration-200 flex items-center space-x-2"
                      >
                        <Volume2 className="w-4 h-4" />
                        <span>Read Aloud</span>
                      </button>
                      <button
                        onClick={copyToClipboard}
                        className="px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg transition-all duration-200 flex items-center space-x-2"
                      >
                        <Copy className="w-4 h-4" />
                        <span>{copySuccess ? 'Copied!' : 'Copy'}</span>
                      </button>
                      <button
                        onClick={downloadSummary}
                        className="px-4 py-2 bg-green-600 hover:bg-green-700 rounded-lg transition-all duration-200 flex items-center space-x-2"
                      >
                        <Download className="w-4 h-4" />
                        <span>Download</span>
                      </button>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="flex items-center justify-center h-80 text-gray-400">
                  <div className="text-center">
                    <div className="relative">
                      <Brain className="w-16 h-16 mx-auto mb-4 text-gray-600" />
                      {isListening && (
                        <div className="absolute -top-2 -right-2">
                          <Mic className="w-6 h-6 text-red-400 animate-pulse" />
                        </div>
                      )}
                    </div>
                    <p className="text-lg font-medium">AI Ready to Summarize</p>
                    <p className="text-sm mt-2">
                      {isListening 
                        ? "🎤 Listening for your voice input..." 
                        : "Your intelligent summary will appear here"
                      }
                    </p>
                    <p className="text-xs text-gray-500 mt-2">
                      💡 Tip: Use the microphone button to dictate your text
                    </p>
                  </div>
                </div>
              )}
            </div>

            {/* Processing Animation */}
            {isGenerating && (
              <div className="bg-gray-800/50 backdrop-blur-sm rounded-xl border border-gray-700/50 p-6">
                <div className="flex items-center justify-center space-x-4">
                  <div className="flex space-x-2">
                    <div className="w-2 h-2 bg-purple-400 rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-pink-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                    <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                  </div>
                  <span className="text-gray-300">AI is analyzing your text...</span>
                </div>
                <div className="mt-4 bg-gray-700 rounded-full h-2 overflow-hidden">
                  <div className="bg-gradient-to-r from-purple-500 to-pink-500 h-2 rounded-full animate-pulse"></div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Features Section */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="bg-gray-800/30 backdrop-blur-sm rounded-xl border border-gray-700/50 p-6 text-center">
            <Zap className="w-8 h-8 text-yellow-400 mx-auto mb-3" />
            <h3 className="text-lg font-semibold mb-2">Lightning Fast</h3>
            <p className="text-gray-400 text-sm">Advanced AI processes your text in seconds, not minutes.</p>
          </div>
          <div className="bg-gray-800/30 backdrop-blur-sm rounded-xl border border-gray-700/50 p-6 text-center">
            <Brain className="w-8 h-8 text-purple-400 mx-auto mb-3" />
            <h3 className="text-lg font-semibold mb-2">Intelligent Analysis</h3>
            <p className="text-gray-400 text-sm">AI understands context and extracts key insights accurately.</p>
          </div>
          <div className="bg-gray-800/30 backdrop-blur-sm rounded-xl border border-gray-700/50 p-6 text-center">
            <Mic className="w-8 h-8 text-blue-400 mx-auto mb-3" />
            <h3 className="text-lg font-semibold mb-2">Voice Input</h3>
            <p className="text-gray-400 text-sm">Speak your text naturally with advanced voice recognition.</p>
          </div>
          <div className="bg-gray-800/30 backdrop-blur-sm rounded-xl border border-gray-700/50 p-6 text-center">
            <Settings className="w-8 h-8 text-green-400 mx-auto mb-3" />
            <h3 className="text-lg font-semibold mb-2">Customizable</h3>
            <p className="text-gray-400 text-sm">Adjust length and style to match your specific needs.</p>
          </div>
        </div>
      </div>
    </div>
  );
}