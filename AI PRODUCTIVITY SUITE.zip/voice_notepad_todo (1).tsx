import React, { useState, useEffect, useRef } from 'react';
import { Plus, Check, Trash2, Mic, MicOff, Volume2, VolumeX } from 'lucide-react';

export default function VoiceNotepadTodo() {
  const [tasks, setTasks] = useState([]);
  const [inputValue, setInputValue] = useState('');
  const [showCelebration, setShowCelebration] = useState(false);
  const [justCompleted, setJustCompleted] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [voiceEnabled, setVoiceEnabled] = useState(true);
  const [transcript, setTranscript] = useState('');
  const [showVoiceHelp, setShowVoiceHelp] = useState(false);
  
  const recognitionRef = useRef(null);
  const speechSynthesisRef = useRef(null);

  // Initialize speech recognition
  useEffect(() => {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = false;
      recognitionRef.current.interimResults = false;
      recognitionRef.current.lang = 'en-US';

      recognitionRef.current.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        setTranscript(transcript);
        handleVoiceCommand(transcript);
      };

      recognitionRef.current.onerror = (event) => {
        console.error('Speech recognition error:', event.error);
        setIsListening(false);
      };

      recognitionRef.current.onend = () => {
        setIsListening(false);
      };
    }
  }, []);

  const speak = (text) => {
    if (!voiceEnabled) return;
    
    // Cancel any ongoing speech
    speechSynthesis.cancel();
    
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 0.9;
    utterance.pitch = 1;
    utterance.volume = 0.8;
    
    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    
    speechSynthesis.speak(utterance);
  };

  const handleVoiceCommand = (command) => {
    const lowerCommand = command.toLowerCase();
    
    if (lowerCommand.includes('add task') || lowerCommand.includes('add todo')) {
      const taskText = lowerCommand.replace(/add task|add todo/g, '').trim();
      if (taskText) {
        addTaskVoice(taskText);
        speak(`Added task: ${taskText}`);
      }
    } else if (lowerCommand.includes('complete') || lowerCommand.includes('finish')) {
      const taskNumber = extractNumber(lowerCommand);
      if (taskNumber && taskNumber <= tasks.length) {
        const task = tasks[taskNumber - 1];
        if (!task.completed) {
          toggleTask(task.id);
          speak(`Completed task: ${task.text}`);
        }
      }
    } else if (lowerCommand.includes('delete') || lowerCommand.includes('remove')) {
      const taskNumber = extractNumber(lowerCommand);
      if (taskNumber && taskNumber <= tasks.length) {
        const task = tasks[taskNumber - 1];
        deleteTask(task.id);
        speak(`Deleted task: ${task.text}`);
      }
    } else if (lowerCommand.includes('read tasks') || lowerCommand.includes('list tasks')) {
      readAllTasks();
    } else {
      // If no command recognized, treat as new task
      addTaskVoice(command);
      speak(`Added task: ${command}`);
    }
  };

  const extractNumber = (text) => {
    const match = text.match(/\d+/);
    return match ? parseInt(match[0]) : null;
  };

  const readAllTasks = () => {
    if (tasks.length === 0) {
      speak("You have no tasks in your notepad.");
      return;
    }
    
    const incompleteTasks = tasks.filter(task => !task.completed);
    const completedTasks = tasks.filter(task => task.completed);
    
    let message = `You have ${tasks.length} tasks total. `;
    
    if (incompleteTasks.length > 0) {
      message += `${incompleteTasks.length} remaining: `;
      incompleteTasks.forEach((task, index) => {
        message += `${index + 1}. ${task.text}. `;
      });
    }
    
    if (completedTasks.length > 0) {
      message += `${completedTasks.length} completed.`;
    }
    
    speak(message);
  };

  const startListening = () => {
    if (recognitionRef.current && !isListening) {
      setIsListening(true);
      recognitionRef.current.start();
    }
  };

  const stopListening = () => {
    if (recognitionRef.current && isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
    }
  };

  const addTask = () => {
    if (inputValue.trim() !== '') {
      setTasks([...tasks, { 
        id: Date.now(), 
        text: inputValue.trim(), 
        completed: false 
      }]);
      setInputValue('');
    }
  };

  const addTaskVoice = (text) => {
    if (text.trim() !== '') {
      setTasks([...tasks, { 
        id: Date.now(), 
        text: text.trim(), 
        completed: false 
      }]);
    }
  };

  const toggleTask = (id) => {
    setTasks(tasks.map(task => {
      if (task.id === id && !task.completed) {
        setJustCompleted(true);
        setTimeout(() => setJustCompleted(false), 2000);
      }
      return task.id === id ? { ...task, completed: !task.completed } : task;
    }));
  };

  const deleteTask = (id) => {
    setTasks(tasks.filter(task => task.id !== id));
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter') {
      addTask();
    }
  };

  const completedCount = tasks.filter(task => task.completed).length;
  const totalCount = tasks.length;

  // Celebration effect when all tasks are completed
  useEffect(() => {
    if (totalCount > 0 && completedCount === totalCount) {
      setShowCelebration(true);
      speak("Congratulations! You've completed all your tasks!");
      setTimeout(() => setShowCelebration(false), 3000);
    }
  }, [completedCount, totalCount]);

  const getCurrentDate = () => {
    const today = new Date();
    return today.toLocaleDateString('en-US', { 
      weekday: 'long', 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-100 to-yellow-50 p-4 relative">
      {/* Celebration Animation */}
      {showCelebration && (
        <div className="fixed inset-0 pointer-events-none z-50 flex items-center justify-center">
          <div className="text-6xl animate-bounce">🎉</div>
          <div className="absolute text-4xl animate-pulse">✨</div>
          <div className="absolute top-20 left-20 text-3xl animate-spin">🌟</div>
          <div className="absolute bottom-20 right-20 text-3xl animate-bounce">🎊</div>
        </div>
      )}
      
      {/* Completion celebration */}
      {justCompleted && (
        <div className="fixed top-20 right-4 bg-green-500 text-white px-4 py-2 rounded-lg shadow-lg animate-bounce z-40">
          Great job! 🎉
        </div>
      )}

      {/* Voice Help Modal */}
      {showVoiceHelp && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg shadow-xl max-w-md">
            <h3 className="text-xl font-bold mb-4">Voice Commands</h3>
            <div className="text-sm space-y-2">
              <p><strong>"Add task [task name]"</strong> - Add a new task</p>
              <p><strong>"Complete task [number]"</strong> - Mark task as done</p>
              <p><strong>"Delete task [number]"</strong> - Remove a task</p>
              <p><strong>"Read tasks"</strong> - Hear all tasks</p>
              <p><strong>Just say the task</strong> - Adds it directly</p>
            </div>
            <button 
              onClick={() => setShowVoiceHelp(false)}
              className="mt-4 bg-blue-500 text-white px-4 py-2 rounded"
            >
              Got it!
            </button>
          </div>
        </div>
      )}
      
      <div className="max-w-lg mx-auto">
        {/* Notepad styling */}
        <div className="bg-white shadow-2xl relative" style={{
          backgroundImage: 'linear-gradient(to bottom, #fef7cd 0%, #fff 100%)',
          borderRadius: '8px 8px 0 0'
        }}>
          {/* Notepad spiral binding */}
          <div className="absolute -top-4 left-0 right-0 h-8 bg-gray-300 rounded-t-lg flex items-center justify-center">
            <div className="flex space-x-4">
              {[...Array(8)].map((_, i) => (
                <div key={i} className="w-3 h-3 bg-gray-400 rounded-full"></div>
              ))}
            </div>
          </div>

          {/* Notepad header */}
          <div className="pt-8 px-6 pb-4 border-b-2 border-red-300">
            <div className="text-center">
              <h1 className="text-3xl font-bold text-gray-800 mb-2" style={{
                fontFamily: 'Courier New, monospace',
                textShadow: '1px 1px 2px rgba(0,0,0,0.1)'
              }}>
                📝 MY NOTEPAD
              </h1>
              <p className="text-gray-600 text-sm" style={{ fontFamily: 'Courier New, monospace' }}>
                {getCurrentDate()}
              </p>
            </div>
          </div>

          {/* Voice Controls */}
          <div className="px-6 py-4 bg-yellow-50 border-b border-yellow-200">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <button
                  onClick={isListening ? stopListening : startListening}
                  className={`p-2 rounded-full transition-all duration-200 ${
                    isListening 
                      ? 'bg-red-500 text-white animate-pulse' 
                      : 'bg-blue-500 text-white hover:bg-blue-600'
                  }`}
                >
                  {isListening ? <MicOff size={20} /> : <Mic size={20} />}
                </button>
                <button
                  onClick={() => setVoiceEnabled(!voiceEnabled)}
                  className={`p-2 rounded-full transition-all duration-200 ${
                    voiceEnabled 
                      ? 'bg-green-500 text-white' 
                      : 'bg-gray-500 text-white'
                  }`}
                >
                  {voiceEnabled ? <Volume2 size={20} /> : <VolumeX size={20} />}
                </button>
                <button
                  onClick={() => setShowVoiceHelp(true)}
                  className="text-blue-500 hover:text-blue-700 text-sm underline"
                >
                  Voice Help
                </button>
              </div>
              <div className="flex items-center space-x-2">
                {isListening && (
                  <span className="text-red-500 text-sm font-medium animate-pulse">
                    🎤 Listening...
                  </span>
                )}
                {isSpeaking && (
                  <span className="text-green-500 text-sm font-medium animate-pulse">
                    🔊 Speaking...
                  </span>
                )}
              </div>
            </div>
            {transcript && (
              <p className="text-sm text-gray-600 mt-2 italic">
                Last heard: "{transcript}"
              </p>
            )}
          </div>

          {/* Add Task Input */}
          <div className="px-6 py-4 bg-blue-50 border-b border-blue-200">
            <div className="flex gap-2">
              <input
                type="text"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Write your task here..."
                className="flex-1 px-4 py-3 border-2 border-blue-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all bg-white"
                style={{ 
                  fontFamily: 'Courier New, monospace',
                  fontSize: '16px',
                  backgroundImage: 'linear-gradient(to right, #e0e7ff 1px, transparent 1px)',
                  backgroundSize: '20px 100%',
                  backgroundRepeat: 'repeat-x'
                }}
              />
              <button
                onClick={addTask}
                className="bg-blue-500 hover:bg-blue-600 text-white p-3 rounded-lg transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-blue-500 transform hover:scale-105"
              >
                <Plus size={20} />
              </button>
            </div>
          </div>

          {/* Task List - Notepad lines */}
          <div className="min-h-96" style={{
            backgroundImage: 'repeating-linear-gradient(transparent, transparent 28px, #e5e7eb 28px, #e5e7eb 30px)',
            backgroundSize: '100% 30px'
          }}>
            {tasks.length === 0 ? (
              <div className="p-8 text-center text-gray-500">
                <div className="text-6xl mb-4">📝</div>
                <p className="text-lg font-medium mb-2" style={{ fontFamily: 'Courier New, monospace' }}>
                  Your notepad is empty
                </p>
                <p className="text-sm" style={{ fontFamily: 'Courier New, monospace' }}>
                  Start writing your tasks above or use voice commands! 🎤
                </p>
              </div>
            ) : (
              <div className="px-6 py-4">
                {tasks.map((task, index) => (
                  <div
                    key={task.id}
                    className="flex items-center gap-3 py-2 mb-1 group"
                    style={{ height: '30px' }}
                  >
                    <span className="text-gray-400 text-sm font-mono w-6 text-right">
                      {index + 1}.
                    </span>
                    <button
                      onClick={() => toggleTask(task.id)}
                      className={`flex-shrink-0 w-5 h-5 rounded border-2 flex items-center justify-center transition-all duration-200 ${
                        task.completed
                          ? 'bg-green-500 border-green-500 text-white'
                          : 'border-gray-400 hover:border-blue-500'
                      }`}
                    >
                      {task.completed && <Check size={12} />}
                    </button>
                    
                    <span
                      className={`flex-1 transition-all duration-200 ${
                        task.completed
                          ? 'text-gray-500 line-through'
                          : 'text-gray-800'
                      }`}
                      style={{ 
                        fontFamily: 'Courier New, monospace', 
                        fontSize: '16px',
                        lineHeight: '30px'
                      }}
                    >
                      {task.text}
                    </span>
                    
                    <button
                      onClick={() => deleteTask(task.id)}
                      className="flex-shrink-0 text-gray-400 hover:text-red-500 p-1 rounded transition-all duration-200 opacity-0 group-hover:opacity-100"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Footer Stats */}
          {tasks.length > 0 && (
            <div className="px-6 py-4 bg-gray-50 border-t border-gray-200">
              <div className="flex justify-between items-center text-sm text-gray-600">
                <span style={{ fontFamily: 'Courier New, monospace' }}>
                  📋 {tasks.filter(t => !t.completed).length} remaining
                </span>
                <span style={{ fontFamily: 'Courier New, monospace' }}>
                  ✅ {completedCount} completed
                </span>
              </div>
              <div className="mt-2 bg-gray-200 rounded-full h-2">
                <div
                  className="bg-gradient-to-r from-blue-500 to-green-500 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${totalCount > 0 ? (completedCount / totalCount) * 100 : 0}%` }}
                ></div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}